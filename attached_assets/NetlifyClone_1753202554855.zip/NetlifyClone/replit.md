# replit.md

## Overview

GitShip is a simplified, open-source clone of Netlify built as a full-stack web application. The platform enables users to connect GitHub repositories and automatically build and deploy static sites with a focus on Jamstack architecture. The application uses a modern monorepo structure with separate client and server directories, implementing a git-driven workflow with atomic deployments.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming (dark theme optimized)
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL using Neon serverless database
- **ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth using OpenID Connect with Passport.js
- **Session Management**: Express sessions with PostgreSQL store
- **Real-time**: WebSocket support for live build logs

### Development Setup
- **Monorepo Structure**: Client and server code in separate directories with shared schema
- **Build System**: Vite for frontend bundling, esbuild for server bundling
- **Development**: Hot reload via Vite dev server with Express middleware
- **Type Safety**: Shared TypeScript interfaces between client and server

## Key Components

### Database Schema
Located in `shared/schema.ts`, defines:
- **Users table**: Stores user authentication data from Replit Auth
- **Projects table**: Repository information, build configuration, and deployment settings
- **Deployments table**: Build status, logs, and deployment metadata
- **Functions table**: Serverless function configurations
- **Analytics table**: Site performance and usage metrics
- **Sessions table**: Required for Replit Auth session management

### Authentication System
- Replit Auth integration with OpenID Connect
- JWT token handling and session management
- Automatic user creation and profile synchronization
- Protected routes with authentication middleware

### Project Management
- GitHub repository integration
- Build configuration (commands, output directories, frameworks)
- Environment variable management
- Custom domain support
- Branch-based deployments

### Deployment Pipeline
- Webhook-triggered builds from Git pushes
- Real-time build log streaming via WebSockets
- Atomic deployment strategy with rollback capability
- Static asset hosting and CDN integration
- Build status tracking and notifications

### Real-time Features
- Live build logs during deployment
- WebSocket connection management
- Real-time deployment status updates

## Recent Major Updates (January 22, 2025)

### Comprehensive Branding and Documentation Update
- **GitShip Logo Integration**: Added flame-themed logo throughout the application interface
- **Complete Color Scheme Update**: Migrated from neon to flame colors (red-orange-yellow-cyan palette)
- **Professional README**: Created comprehensive documentation showcasing all features and capabilities
- **GitHub OAuth Integration**: Full authentication system with repository browser and framework detection
- **Visual Identity Consolidation**: Consistent flame branding across all UI components and interactions

### Previous Updates (January 19, 2025)

### Advanced Feature Implementation
- **Real-time Build Logs**: WebSocket integration for live build streaming with auto-scroll and download capabilities
- **Team Collaboration**: Complete team management with role-based permissions (Owner, Admin, Developer, Viewer)
- **Domain Management**: Custom domain configuration with DNS setup guidance and SSL status tracking
- **Enhanced Project Detail**: Comprehensive tabbed interface with overview, builds, analytics, domains, team, and settings
- **Professional UI Components**: Advanced sidebar navigation, build log streaming, and team invitation system

### Technical Infrastructure
- **WebSocket Server**: Real-time communication for build logs with subscription management
- **Team API Routes**: Full CRUD operations for team member management and invitations
- **Domain API Routes**: Custom domain management with verification and SSL tracking
- **Enhanced Database Schema**: Added team collaboration and domain management data structures
- **Component Architecture**: Modular components for build logs, team management, and domain configuration

### User Experience Improvements
- **Tabbed Project Interface**: Organized project management with dedicated sections for different functionalities
- **Real-time Updates**: Live build progress with WebSocket streaming and status indicators
- **Professional Design**: Dark mode with neon accents, consistent with GitShip branding
- **Comprehensive Statistics**: Detailed project metrics including success rates, build times, and deployment history

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, creating/updating user records
2. **Project Creation**: Users connect GitHub repositories, storing configuration in projects table
3. **Team Collaboration**: Project owners invite team members with role-based access control
4. **Build Trigger**: Manual or webhook-triggered builds with real-time WebSocket log streaming
5. **Domain Configuration**: Custom domain setup with DNS verification and SSL certificate management
6. **Analytics Tracking**: Comprehensive metrics collection for performance monitoring

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless database client
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives
- **wouter**: Lightweight React router
- **passport**: Authentication middleware
- **express-session**: Session management

### Development Dependencies
- **vite**: Frontend build tool and dev server
- **typescript**: Type checking and compilation
- **tailwindcss**: Utility-first CSS framework
- **postcss**: CSS processing
- **esbuild**: Fast JavaScript/TypeScript bundler for server

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling integration

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend development
- Express server with automatic restart on changes
- Shared TypeScript configuration for type safety
- Real-time error reporting and debugging tools

### Production Build
- Frontend: Vite builds optimized React bundle to `dist/public`
- Backend: esbuild bundles Express server to `dist/index.js`
- Database: Drizzle migrations for schema updates
- Environment: PostgreSQL database provisioning required

### Infrastructure Requirements
- PostgreSQL database (configured via DATABASE_URL)
- Node.js runtime environment
- Static file serving capability
- WebSocket support for real-time features
- Session secret for authentication (SESSION_SECRET)

The application follows a clean separation of concerns with shared TypeScript types, making it easy to maintain type safety across the full stack while providing a modern development experience optimized for the Replit platform.

## Production Readiness Status

### Current MVP Features (Complete)
- **Authentication**: Replit Auth integration with user management
- **Project Management**: Full CRUD operations for projects with GitHub repository configuration
- **Real-time Build Logs**: WebSocket streaming with live build progress and downloadable logs
- **Team Collaboration**: Role-based team management with invitation system
- **Domain Management**: Custom domain configuration with DNS setup guidance
- **Analytics Dashboard**: Performance metrics and deployment statistics
- **Environment Variables**: Secure environment variable management
- **Responsive UI**: Professional dark mode interface with neon accents

### Production Requirements Identified
- **Git Integration**: Real GitHub/GitLab API integration (currently mocked)
- **Build Infrastructure**: Docker containerization and scalable build workers
- **CDN Integration**: Global content delivery network for asset distribution
- **SSL Management**: Automated SSL certificate provisioning via Let's Encrypt
- **Payment Processing**: Stripe integration for subscription billing
- **Monitoring**: Error tracking, performance monitoring, and uptime alerts
- **Security**: Enterprise authentication, audit logs, and compliance features

The current codebase provides a solid foundation for production deployment, with all core architectural patterns and user experience flows implemented. 

## Project Consolidation Strategy

### Dual Project Analysis (January 19, 2025)
**Discovery**: User has two separate GitShip implementations with complementary features:
- **Netlify-clone** (this project): Advanced UI, team collaboration, domain management, comprehensive database
- **GitShip** (other project): Real GitHub OAuth integration, repository browser, framework auto-detection

### Recommended Merge Plan
**Base Project**: This Netlify-clone (superior architecture and advanced features)
**Merge Target**: GitHub integration features from GitShip project
**Timeline**: 4 weeks for complete consolidation before 6-project integration

The merged platform will combine the best of both implementations to create a comprehensive Netlify alternative. See PRODUCTION_ROADMAP.md for detailed implementation plan.