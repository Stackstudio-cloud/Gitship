import passport from "passport";
import { Strategy as GitHubStrategy } from "passport-github2";
import type { Express, RequestHandler } from "express";
import { storage } from "./storage";

export async function setupGitHubAuth(app: Express) {
  if (!process.env.GITHUB_CLIENT_ID || !process.env.GITHUB_CLIENT_SECRET) {
    console.warn("GitHub OAuth not configured - missing GITHUB_CLIENT_ID or GITHUB_CLIENT_SECRET");
    return;
  }

  // GitHub OAuth Strategy
  passport.use('github', new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackURL: "/api/auth/github/callback",
    scope: ['repo', 'user:email']
  }, async (accessToken: string, refreshToken: string, profile: any, done: any) => {
    try {
      // Store GitHub token for the current user session
      const githubData = {
        accessToken,
        refreshToken,
        profile: {
          id: profile.id,
          username: profile.username,
          email: profile.emails?.[0]?.value,
          name: profile.displayName,
          avatar: profile.photos?.[0]?.value
        }
      };
      
      done(null, githubData);
    } catch (error) {
      console.error("GitHub auth error:", error);
      done(error, null);
    }
  }));

  // GitHub OAuth routes
  app.get('/api/auth/github', passport.authenticate('github'));
  
  app.get('/api/auth/github/callback', 
    passport.authenticate('github', { session: false }),
    async (req: any, res) => {
      try {
        // Store GitHub token in user session
        if (req.user && req.session) {
          req.session.githubAuth = req.user;
        }
        
        // Redirect back to dashboard with success
        res.redirect('/?github=connected');
      } catch (error) {
        console.error("GitHub callback error:", error);
        res.redirect('/?github=error');
      }
    }
  );

  // Disconnect GitHub
  app.post('/api/auth/github/disconnect', async (req: any, res) => {
    try {
      if (req.session?.githubAuth) {
        delete req.session.githubAuth;
      }
      res.json({ message: "GitHub disconnected successfully" });
    } catch (error) {
      console.error("GitHub disconnect error:", error);
      res.status(500).json({ message: "Failed to disconnect GitHub" });
    }
  });
}

export const requireGitHubAuth: RequestHandler = (req: any, res, next) => {
  if (!req.session?.githubAuth?.accessToken) {
    return res.status(401).json({ 
      message: "GitHub authentication required",
      needsGitHubAuth: true 
    });
  }
  next();
};