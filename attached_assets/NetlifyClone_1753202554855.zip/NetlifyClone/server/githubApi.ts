import { Octokit } from "@octokit/rest";

export interface GitHubRepository {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  clone_url: string;
  ssh_url: string;
  default_branch: string;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  updated_at: string;
  private: boolean;
  owner: {
    login: string;
    avatar_url: string;
  };
}

export interface GitHubBranch {
  name: string;
  commit: {
    sha: string;
    url: string;
  };
  protected: boolean;
}

export interface FrameworkDetection {
  framework: string;
  buildCommand: string;
  outputDirectory: string;
  installCommand: string;
}

export class GitHubService {
  private octokit: Octokit;

  constructor(accessToken: string) {
    this.octokit = new Octokit({
      auth: accessToken,
    });
  }

  async getUserRepositories(page = 1, per_page = 30): Promise<GitHubRepository[]> {
    try {
      const response = await this.octokit.repos.listForAuthenticatedUser({
        sort: 'updated',
        direction: 'desc',
        page,
        per_page,
      });
      return response.data as GitHubRepository[];
    } catch (error) {
      console.error("Error fetching repositories:", error);
      throw new Error("Failed to fetch repositories from GitHub");
    }
  }

  async getRepository(owner: string, repo: string): Promise<GitHubRepository> {
    try {
      const response = await this.octokit.repos.get({
        owner,
        repo,
      });
      return response.data as GitHubRepository;
    } catch (error) {
      console.error("Error fetching repository:", error);
      throw new Error("Failed to fetch repository from GitHub");
    }
  }

  async getRepositoryBranches(owner: string, repo: string): Promise<GitHubBranch[]> {
    try {
      const response = await this.octokit.repos.listBranches({
        owner,
        repo,
      });
      return response.data as GitHubBranch[];
    } catch (error) {
      console.error("Error fetching branches:", error);
      throw new Error("Failed to fetch branches from GitHub");
    }
  }

  async getPackageJson(owner: string, repo: string, ref = 'main'): Promise<any> {
    try {
      const response = await this.octokit.repos.getContent({
        owner,
        repo,
        path: 'package.json',
        ref,
      });
      
      if ('content' in response.data) {
        const content = Buffer.from(response.data.content, 'base64').toString();
        return JSON.parse(content);
      }
      return null;
    } catch (error) {
      // package.json might not exist, try other common files
      return null;
    }
  }

  async detectFramework(owner: string, repo: string, ref = 'main'): Promise<FrameworkDetection> {
    try {
      const packageJson = await this.getPackageJson(owner, repo, ref);
      
      if (packageJson) {
        const dependencies = { 
          ...packageJson.dependencies, 
          ...packageJson.devDependencies 
        };
        
        // Framework detection logic
        if (dependencies['next']) {
          return {
            framework: 'Next.js',
            buildCommand: 'npm run build',
            outputDirectory: '.next',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['nuxt'] || dependencies['@nuxt/kit']) {
          return {
            framework: 'Nuxt.js',
            buildCommand: 'npm run generate',
            outputDirectory: 'dist',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['@angular/core']) {
          return {
            framework: 'Angular',
            buildCommand: 'npm run build',
            outputDirectory: 'dist',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['vue']) {
          return {
            framework: 'Vue.js',
            buildCommand: 'npm run build',
            outputDirectory: 'dist',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['svelte']) {
          return {
            framework: 'Svelte',
            buildCommand: 'npm run build',
            outputDirectory: 'public',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['gatsby']) {
          return {
            framework: 'Gatsby',
            buildCommand: 'npm run build',
            outputDirectory: 'public',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['astro']) {
          return {
            framework: 'Astro',
            buildCommand: 'npm run build',
            outputDirectory: 'dist',
            installCommand: 'npm install'
          };
        }
        
        if (dependencies['react']) {
          return {
            framework: 'React',
            buildCommand: 'npm run build',
            outputDirectory: 'build',
            installCommand: 'npm install'
          };
        }
      }
      
      // Check for static site files
      try {
        await this.octokit.repos.getContent({
          owner,
          repo,
          path: 'index.html',
          ref,
        });
        
        return {
          framework: 'Static HTML',
          buildCommand: '',
          outputDirectory: '.',
          installCommand: ''
        };
      } catch {
        // No index.html found
      }
      
      // Default fallback
      return {
        framework: 'Static Site',
        buildCommand: '',
        outputDirectory: '.',
        installCommand: ''
      };
      
    } catch (error) {
      console.error("Error detecting framework:", error);
      return {
        framework: 'Unknown',
        buildCommand: 'npm run build',
        outputDirectory: 'dist',
        installCommand: 'npm install'
      };
    }
  }

  async createWebhook(owner: string, repo: string, webhookUrl: string): Promise<any> {
    try {
      const response = await this.octokit.repos.createWebhook({
        owner,
        repo,
        config: {
          url: webhookUrl,
          content_type: 'json',
          secret: process.env.WEBHOOK_SECRET || 'gitship-webhook-secret',
        },
        events: ['push', 'pull_request'],
      });
      return response.data;
    } catch (error) {
      console.error("Error creating webhook:", error);
      throw new Error("Failed to create webhook");
    }
  }

  async deleteWebhook(owner: string, repo: string, hookId: number): Promise<void> {
    try {
      await this.octokit.repos.deleteWebhook({
        owner,
        repo,
        hook_id: hookId,
      });
    } catch (error) {
      console.error("Error deleting webhook:", error);
      throw new Error("Failed to delete webhook");
    }
  }
}