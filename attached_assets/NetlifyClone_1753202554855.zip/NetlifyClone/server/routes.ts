import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { setupGitHubAuth, requireGitHubAuth } from "./githubAuth";
import { GitHubService } from "./githubApi";
import { insertProjectSchema, insertDeploymentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);
  await setupGitHubAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Project routes
  app.get('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projects = await storage.getUserProjects(userId);
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.patch('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const updates = req.body;
      const updatedProject = await storage.updateProject(projectId, updates);
      res.json(updatedProject);
    } catch (error) {
      console.error("Error updating project:", error);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete('/api/projects/:id', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      await storage.deleteProject(projectId);
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  app.post('/api/projects', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const projectData = insertProjectSchema.parse({
        ...req.body,
        userId,
      });
      
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: error.errors });
      }
      console.error("Error creating project:", error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Deployment routes
  app.get('/api/projects/:id/deployments', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const deployments = await storage.getProjectDeployments(projectId);
      res.json(deployments);
    } catch (error) {
      console.error("Error fetching deployments:", error);
      res.status(500).json({ message: "Failed to fetch deployments" });
    }
  });

  app.get('/api/deployments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const deploymentId = parseInt(req.params.id);
      const deployment = await storage.getDeployment(deploymentId);
      
      if (!deployment) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      const project = deployment.projectId ? await storage.getProject(deployment.projectId) : null;
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Deployment not found" });
      }
      
      res.json(deployment);
    } catch (error) {
      console.error("Error fetching deployment:", error);
      res.status(500).json({ message: "Failed to fetch deployment" });
    }
  });

  app.post('/api/projects/:id/deploy', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const deploymentData = insertDeploymentSchema.parse({
        projectId,
        status: "building",
        environment: req.body.environment || "production",
        buildLogs: "",
        startedAt: new Date(),
      });
      
      const deployment = await storage.createDeployment(deploymentData);
      
      // Start build process in background
      if (deployment.id) {
        simulateBuild(deployment.id);
      }
      
      res.status(201).json(deployment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid deployment data", errors: error.errors });
      }
      console.error("Error creating deployment:", error);
      res.status(500).json({ message: "Failed to create deployment" });
    }
  });

  // Analytics routes
  app.get('/api/projects/:id/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const analytics = await storage.getProjectAnalytics(projectId);
      
      // If no analytics exist, create sample data for demonstration
      if (analytics.length === 0) {
        await storage.updateAnalytics(projectId, {
          pageViews: 1247,
          uniqueVisitors: 856,
          bandwidth: 2340000000, // 2.34 GB
          avgLoadTime: 1100, // 1.1s
        });
        
        const newAnalytics = await storage.getProjectAnalytics(projectId);
        return res.json(newAnalytics);
      }
      
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // Environment variables routes
  app.get('/api/projects/:id/environment-variables', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const envVars = await storage.getEnvironmentVariables(projectId);
      res.json(envVars);
    } catch (error) {
      console.error("Error fetching environment variables:", error);
      res.status(500).json({ message: "Failed to fetch environment variables" });
    }
  });

  app.post('/api/projects/:id/environment-variables', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const { key, value } = req.body;
      const envVar = await storage.setEnvironmentVariable(projectId, key, value);
      res.json(envVar);
    } catch (error) {
      console.error("Error creating environment variable:", error);
      res.status(500).json({ message: "Failed to create environment variable" });
    }
  });

  app.delete('/api/projects/:id/environment-variables/:key', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      await storage.deleteEnvironmentVariable(projectId, req.params.key);
      res.json({ message: "Environment variable deleted successfully" });
    } catch (error) {
      console.error("Error deleting environment variable:", error);
      res.status(500).json({ message: "Failed to delete environment variable" });
    }
  });

  // Team collaboration routes (mock for demo)
  app.get('/api/projects/:id/team', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Mock team data for demonstration
      const teamMembers = [
        {
          id: req.user.claims.sub,
          email: req.user.claims.email,
          firstName: req.user.claims.first_name,
          lastName: req.user.claims.last_name,
          profileImageUrl: req.user.claims.profile_image_url,
          role: 'owner',
          joinedAt: project.createdAt,
        }
      ];
      
      res.json(teamMembers);
    } catch (error) {
      console.error("Error fetching team:", error);
      res.status(500).json({ message: "Failed to fetch team members" });
    }
  });

  app.post('/api/projects/:id/team/invite', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const { email, role } = req.body;
      
      // Mock invitation response
      res.json({ 
        message: "Invitation sent successfully",
        invitationId: Math.random().toString(36).substr(2, 9),
        email,
        role 
      });
    } catch (error) {
      console.error("Error sending invitation:", error);
      res.status(500).json({ message: "Failed to send invitation" });
    }
  });

  // Domain management routes (mock for demo)
  app.get('/api/projects/:id/domains', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      // Mock domain data
      res.json([]);
    } catch (error) {
      console.error("Error fetching domains:", error);
      res.status(500).json({ message: "Failed to fetch domains" });
    }
  });

  app.post('/api/projects/:id/domains', isAuthenticated, async (req: any, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project || project.userId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      const { domain } = req.body;
      
      // Mock domain creation
      const newDomain = {
        id: Math.floor(Math.random() * 1000),
        domain,
        status: 'pending',
        sslStatus: 'pending',
        createdAt: new Date().toISOString(),
      };
      
      res.json(newDomain);
    } catch (error) {
      console.error("Error adding domain:", error);
      res.status(500).json({ message: "Failed to add domain" });
    }
  });

  // GitHub integration routes
  app.get('/api/github/status', isAuthenticated, async (req: any, res) => {
    try {
      const isConnected = !!req.session?.githubAuth?.accessToken;
      const githubUser = req.session?.githubAuth?.profile;
      
      res.json({ 
        isConnected,
        user: githubUser || null
      });
    } catch (error) {
      console.error("Error checking GitHub status:", error);
      res.status(500).json({ message: "Failed to check GitHub status" });
    }
  });

  app.get('/api/github/repositories', isAuthenticated, requireGitHubAuth, async (req: any, res) => {
    try {
      const githubService = new GitHubService(req.session.githubAuth.accessToken);
      const page = parseInt(req.query.page as string) || 1;
      const repositories = await githubService.getUserRepositories(page, 20);
      
      res.json(repositories);
    } catch (error) {
      console.error("Error fetching repositories:", error);
      res.status(500).json({ message: "Failed to fetch repositories" });
    }
  });

  app.get('/api/github/repositories/:owner/:repo', isAuthenticated, requireGitHubAuth, async (req: any, res) => {
    try {
      const { owner, repo } = req.params;
      const githubService = new GitHubService(req.session.githubAuth.accessToken);
      
      const [repository, branches, framework] = await Promise.all([
        githubService.getRepository(owner, repo),
        githubService.getRepositoryBranches(owner, repo),
        githubService.detectFramework(owner, repo)
      ]);
      
      res.json({
        repository,
        branches,
        framework
      });
    } catch (error) {
      console.error("Error fetching repository details:", error);
      res.status(500).json({ message: "Failed to fetch repository details" });
    }
  });

  app.post('/api/github/repositories/:owner/:repo/webhook', isAuthenticated, requireGitHubAuth, async (req: any, res) => {
    try {
      const { owner, repo } = req.params;
      const githubService = new GitHubService(req.session.githubAuth.accessToken);
      
      const webhookUrl = `${req.protocol}://${req.get('host')}/api/webhooks/github`;
      const webhook = await githubService.createWebhook(owner, repo, webhookUrl);
      
      res.json(webhook);
    } catch (error) {
      console.error("Error creating webhook:", error);
      res.status(500).json({ message: "Failed to create webhook" });
    }
  });

  const httpServer = createServer(app);
  
  // Add WebSocket server for real-time build logs
  const { WebSocketServer } = await import('ws');
  const WebSocket = (await import('ws')).default;
  
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const deploymentSubscriptions = new Map<string, Set<any>>();
  
  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');
    
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'subscribe' && data.deploymentId) {
          if (!deploymentSubscriptions.has(data.deploymentId)) {
            deploymentSubscriptions.set(data.deploymentId, new Set());
          }
          deploymentSubscriptions.get(data.deploymentId)!.add(ws);
          
          console.log(`Client subscribed to deployment ${data.deploymentId}`);
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      // Remove client from all subscriptions
      deploymentSubscriptions.forEach((clients, deploymentId) => {
        clients.delete(ws);
        if (clients.size === 0) {
          deploymentSubscriptions.delete(deploymentId);
        }
      });
      console.log('WebSocket client disconnected');
    });
  });
  
  // Function to broadcast build logs to subscribed clients
  const broadcastBuildLog = (deploymentId: string, message: string) => {
    const clients = deploymentSubscriptions.get(deploymentId);
    if (clients) {
      const payload = JSON.stringify({
        type: 'log',
        deploymentId,
        message,
        timestamp: new Date().toISOString()
      });
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(payload);
        }
      });
    }
  };
  
  return httpServer;
}

// Simulate build process
async function simulateBuild(deploymentId: number) {
  const buildSteps = [
    { message: "Preparing build environment...", delay: 1000 },
    { message: "Cloning repository...", delay: 2000 },
    { message: "Installing dependencies...", delay: 3000 },
    { message: "✓ Dependencies installed", delay: 1000 },
    { message: "Running build command...", delay: 4000 },
    { message: "✓ Build completed successfully", delay: 2000 },
    { message: "Optimizing images...", delay: 1000 },
    { message: "✓ Images optimized (67% reduction)", delay: 2000 },
    { message: "Uploading to CDN...", delay: 3000 },
    { message: "✓ Deploy successful", delay: 1000, status: "success" },
    { message: `Site published to https://deploy-${deploymentId}.gitship.app`, delay: 500 },
  ];

  let logs = "";
  
  for (const step of buildSteps) {
    await new Promise(resolve => setTimeout(resolve, step.delay));
    
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = `[${timestamp}] ${step.message}`;
    logs += logEntry + "\n";
    
    // Update deployment status if specified
    if (step.status) {
      const deployment = await storage.getDeployment(deploymentId);
      if (deployment && deployment.startedAt) {
        await storage.updateDeployment(deploymentId, {
          status: step.status,
          buildLogs: logs,
          ...(step.status === "success" && {
            completedAt: new Date(),
            deployUrl: `https://deploy-${deploymentId}.gitship.app`,
            buildTime: Math.floor((Date.now() - deployment.startedAt.getTime()) / 1000),
          }),
        });
      }
    } else {
      await storage.updateDeployment(deploymentId, { buildLogs: logs });
    }
    
    // Broadcast log to connected WebSocket clients
    broadcastBuildLog(deploymentId, logEntry);
  }
}

function broadcastBuildLog(deploymentId: number, logEntry: string) {
  // This would be implemented with access to the WebSocket server
  // For now, we'll just log to console
  console.log(`[Deployment ${deploymentId}] ${logEntry}`);
}