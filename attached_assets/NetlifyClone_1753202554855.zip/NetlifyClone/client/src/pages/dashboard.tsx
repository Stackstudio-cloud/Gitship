import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import Sidebar from "@/components/sidebar";
import CreateProjectDialog from "@/components/create-project-dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Plus, BarChart3, Clock, Globe, TrendingUp, Users, Activity } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Project, Deployment } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: recentDeployments = [] } = useQuery<Deployment[]>({
    queryKey: ["/api/deployments/recent"],
    retry: false,
    enabled: false, // Disable for now as we don't have this endpoint
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-neon-green text-dark-900';
      case 'building':
        return 'bg-orange-500 text-white';
      case 'failed':
        return 'bg-red-500 text-white';
      case 'queued':
        return 'bg-gray-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  if (isLoading || projectsLoading) {
    return (
      <div className="min-h-screen bg-dark-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-neon-cyan border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      <Navbar />
      <div className="flex">
        <Sidebar projects={projects} />
        
        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          {/* Dashboard Header */}
          <div className="p-6 border-b border-dark-600">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white">Dashboard</h1>
                <p className="text-gray-400 mt-1">Manage your projects and deployments</p>
              </div>
              <CreateProjectDialog />
            </div>
          </div>

          {/* Quick Stats */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card className="bg-dark-800 border-dark-600">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Total Projects</p>
                      <p className="text-2xl font-bold text-white">{projects.length}</p>
                    </div>
                    <div className="w-10 h-10 bg-neon-cyan/20 rounded-lg flex items-center justify-center">
                      <Globe className="w-5 h-5 text-neon-cyan" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-dark-800 border-dark-600">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Active Deployments</p>
                      <p className="text-2xl font-bold text-white">
                        {projects.filter(p => p.status === 'success').length}
                      </p>
                    </div>
                    <div className="w-10 h-10 bg-neon-green/20 rounded-lg flex items-center justify-center">
                      <Activity className="w-5 h-5 text-neon-green" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-dark-800 border-dark-600">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">This Month</p>
                      <p className="text-2xl font-bold text-white">24.7K</p>
                      <p className="text-xs text-neon-green">+12.5% views</p>
                    </div>
                    <div className="w-10 h-10 bg-neon-purple/20 rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-neon-purple" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-dark-800 border-dark-600">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Team Size</p>
                      <p className="text-2xl font-bold text-white">1</p>
                      <p className="text-xs text-gray-400">Personal account</p>
                    </div>
                    <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-yellow-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold mb-2">Dashboard</h1>
                <p className="text-gray-400">Manage your projects and deployments</p>
              </div>
              <Button className="bg-gradient-to-r from-neon-cyan to-neon-purple text-dark-900 font-semibold hover:shadow-lg hover:shadow-neon-cyan/25">
                <Plus className="w-4 h-4 mr-2" />
                New Project
              </Button>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-dark-800 border-dark-600 hover:border-neon-green/50 transition-all">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Active Projects</CardTitle>
                  <Globe className="h-4 w-4 text-neon-green" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-neon-green">{projects.length}</div>
                  <p className="text-xs text-gray-400">+20.1% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-dark-800 border-dark-600 hover:border-neon-cyan/50 transition-all">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Deployments</CardTitle>
                  <BarChart3 className="h-4 w-4 text-neon-cyan" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-neon-cyan">12</div>
                  <p className="text-xs text-gray-400">+180.1% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-dark-800 border-dark-600 hover:border-neon-purple/50 transition-all">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-gray-400">Avg Build Time</CardTitle>
                  <Clock className="h-4 w-4 text-neon-purple" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-neon-purple">1.2min</div>
                  <p className="text-xs text-green-400">-5% improvement</p>
                </CardContent>
              </Card>
            </div>

            {/* Projects Grid */}
            <div className="grid gap-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Your Projects</h2>
                <Button variant="outline" className="border-gray-600 text-gray-400 hover:border-neon-cyan hover:text-neon-cyan">
                  View All
                </Button>
              </div>

              {projects.length === 0 ? (
                <Card className="bg-dark-800 border-dark-600 border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <div className="w-16 h-16 bg-dark-700 rounded-full flex items-center justify-center mb-4">
                      <Plus className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">No projects yet</h3>
                    <p className="text-gray-400 text-center mb-4 max-w-sm">
                      Connect your first GitHub repository to get started with deployments
                    </p>
                    <Button className="bg-gradient-to-r from-neon-cyan to-neon-purple text-dark-900 font-semibold">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Project
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects.map((project) => (
                    <Link key={project.id} href={`/projects/${project.id}`}>
                      <Card className="bg-dark-800 border-dark-600 hover:border-neon-cyan/50 transition-all cursor-pointer group">
                        <CardHeader>
                          <div className="flex items-center justify-between">
                            <CardTitle className="group-hover:text-neon-cyan transition-colors">
                              {project.name}
                            </CardTitle>
                            <Badge className="bg-neon-green/20 text-neon-green">
                              Active
                            </Badge>
                          </div>
                          <CardDescription className="text-gray-400">
                            {project.description || 'No description'}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex items-center text-sm text-gray-400">
                              <span className="w-3 h-3 bg-neon-green rounded-full mr-2"></span>
                              {project.framework || 'Unknown'}
                            </div>
                            <div className="flex items-center text-sm text-gray-400">
                              <Globe className="w-3 h-3 mr-2" />
                              {project.customDomain || `${project.name}.gitship.app`}
                            </div>
                            <div className="flex items-center text-sm text-gray-400">
                              <Clock className="w-3 h-3 mr-2" />
                              Last updated {new Date(project.updatedAt!).toLocaleDateString()}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
