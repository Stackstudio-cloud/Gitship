import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Bell, ChevronDown, Settings, LogOut, Rocket } from "lucide-react";
import gitshipLogo from "../assets/gitship-logo.png";

export default function Navbar() {
  const { user } = useAuth();

  return (
    <nav className="bg-dark-800 border-b border-dark-600 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <img 
              src={gitshipLogo} 
              alt="GitShip"
              className="h-8 w-auto"
            />
          </div>
          <div className="hidden md:flex items-center space-x-6 ml-8">
            <a href="/" className="text-flame-cyan hover:text-white transition-colors">Sites</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Functions</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Analytics</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">Settings</a>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-flame-orange">
            <Bell className="w-4 h-4" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 hover:bg-dark-700">
                <div className="flex items-center space-x-2">
                  <img 
                    src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=32&h=32"} 
                    alt="Profile" 
                    className="w-8 h-8 rounded-full object-cover border border-flame-orange"
                  />
                  <span className="text-sm font-medium hidden md:block">
                    {user?.firstName && user?.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user?.email?.split('@')[0] || 'User'
                    }
                  </span>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-dark-800 border-dark-600">
              <DropdownMenuItem className="hover:bg-dark-700 focus:bg-dark-700">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="hover:bg-dark-700 focus:bg-dark-700 text-red-400"
                onClick={() => window.location.href = '/api/logout'}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
