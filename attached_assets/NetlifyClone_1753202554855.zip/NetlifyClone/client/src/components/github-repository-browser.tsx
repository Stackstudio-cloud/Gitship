import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Github, 
  Search, 
  Star, 
  GitFork, 
  Lock, 
  Globe,
  Calendar,
  Code,
  AlertCircle,
  CheckCircle,
  ExternalLink
} from "lucide-react";

interface GitHubRepository {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  clone_url: string;
  ssh_url: string;
  default_branch: string;
  language: string | null;
  stargazers_count: number;
  forks_count: number;
  updated_at: string;
  private: boolean;
  owner: {
    login: string;
    avatar_url: string;
  };
}

interface GitHubStatus {
  isConnected: boolean;
  user: {
    id: string;
    username: string;
    email: string;
    name: string;
    avatar: string;
  } | null;
}

interface RepositoryBrowserProps {
  onRepositorySelect: (repository: GitHubRepository, framework: any) => void;
  selectedRepository?: GitHubRepository | null;
}

export default function GitHubRepositoryBrowser({ onRepositorySelect, selectedRepository }: RepositoryBrowserProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const queryClient = useQueryClient();

  const { data: githubStatus, isLoading: statusLoading } = useQuery<GitHubStatus>({
    queryKey: ["/api/github/status"],
    retry: false,
  });

  const { data: repositories = [], isLoading: reposLoading, error: reposError } = useQuery<GitHubRepository[]>({
    queryKey: ["/api/github/repositories", currentPage],
    enabled: githubStatus?.isConnected,
    retry: false,
  });

  const connectGitHubMutation = useMutation({
    mutationFn: async () => {
      window.location.href = "/api/auth/github";
    },
  });

  const selectRepositoryMutation = useMutation({
    mutationFn: async (repository: GitHubRepository) => {
      const response = await apiRequest(`/api/github/repositories/${repository.owner.login}/${repository.name}`);
      return { repository, ...response };
    },
    onSuccess: (data) => {
      onRepositorySelect(data.repository, data.framework);
    },
  });

  const filteredRepositories = repositories.filter(repo =>
    repo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    repo.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    repo.language?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (statusLoading) {
    return (
      <Card className="bg-dark-800 border-dark-600">
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-flame-orange"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!githubStatus?.isConnected) {
    return (
      <Card className="bg-dark-800 border-dark-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Github className="w-5 h-5 mr-2" />
            Connect GitHub
          </CardTitle>
          <CardDescription className="text-gray-400">
            Connect your GitHub account to access your repositories
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Github className="w-16 h-16 mx-auto mb-4 text-gray-500" />
            <h3 className="text-lg font-semibold text-white mb-2">GitHub Integration Required</h3>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              To create projects from your repositories, you need to connect your GitHub account. 
              This allows GitShip to access your repositories and set up automatic deployments.
            </p>
            <Button
              onClick={() => connectGitHubMutation.mutate()}
              disabled={connectGitHubMutation.isPending}
              className="bg-[#238636] hover:bg-[#2ea043] text-white border-0"
            >
              <Github className="w-4 h-4 mr-2" />
              Connect with GitHub
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (reposError) {
    return (
      <Card className="bg-dark-800 border-dark-600">
        <CardContent className="p-6">
          <div className="text-center py-8">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-500" />
            <h3 className="text-lg font-semibold text-white mb-2">Failed to Load Repositories</h3>
            <p className="text-gray-400 mb-6">
              Unable to fetch your GitHub repositories. Please try reconnecting your account.
            </p>
            <Button
              onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/github/repositories"] })}
              variant="outline"
              className="border-gray-600 text-white hover:bg-dark-700"
            >
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-dark-800 border-dark-600">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center">
              <Github className="w-5 h-5 mr-2" />
              Select Repository
            </CardTitle>
            <CardDescription className="text-gray-400">
              Connected as @{githubStatus.user?.username}
            </CardDescription>
          </div>
          {githubStatus.user?.avatar && (
            <img
              src={githubStatus.user.avatar}
              alt={githubStatus.user.username}
              className="w-10 h-10 rounded-full border-2 border-dark-600"
            />
          )}
        </div>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search repositories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-dark-700 border-dark-600 text-white placeholder-gray-400"
          />
        </div>
      </CardHeader>
      
      <CardContent>
        {reposLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-flame-orange"></div>
          </div>
        ) : filteredRepositories.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Code className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No repositories found</p>
            {searchTerm && (
              <p className="text-sm">Try adjusting your search terms</p>
            )}
          </div>
        ) : (
          <ScrollArea className="h-96">
            <div className="space-y-3">
              {filteredRepositories.map((repo) => (
                <div
                  key={repo.id}
                  className={`p-4 rounded-lg border transition-all cursor-pointer ${
                    selectedRepository?.id === repo.id
                      ? 'border-flame-orange bg-flame-orange/10'
                      : 'border-dark-600 bg-dark-700 hover:border-gray-500'
                  }`}
                  onClick={() => selectRepositoryMutation.mutate(repo)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-medium text-white truncate">
                          {repo.name}
                        </h3>
                        {repo.private ? (
                          <Lock className="w-4 h-4 text-yellow-500" />
                        ) : (
                          <Globe className="w-4 h-4 text-green-500" />
                        )}
                        {repo.language && (
                          <Badge variant="outline" className="text-xs">
                            {repo.language}
                          </Badge>
                        )}
                      </div>
                      
                      {repo.description && (
                        <p className="text-sm text-gray-400 mb-3 line-clamp-2">
                          {repo.description}
                        </p>
                      )}
                      
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3" />
                          <span>{repo.stargazers_count}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <GitFork className="w-3 h-3" />
                          <span>{repo.forks_count}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>
                            Updated {new Date(repo.updated_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      {selectedRepository?.id === repo.id && (
                        <CheckCircle className="w-5 h-5 text-flame-yellow" />
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(repo.html_url, '_blank');
                        }}
                        className="text-gray-400 hover:text-white"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {selectRepositoryMutation.isPending && selectedRepository?.id === repo.id && (
                    <div className="mt-3 pt-3 border-t border-dark-600">
                      <div className="flex items-center space-x-2 text-sm text-flame-orange">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-flame-orange"></div>
                        <span>Analyzing repository...</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
        
        {filteredRepositories.length > 0 && (
          <div className="mt-4 pt-4 border-t border-dark-600">
            <div className="flex items-center justify-between text-sm text-gray-400">
              <span>
                Showing {filteredRepositories.length} of {repositories.length} repositories
              </span>
              {repositories.length >= 20 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  className="text-flame-cyan hover:text-flame-orange"
                >
                  Load more
                </Button>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}